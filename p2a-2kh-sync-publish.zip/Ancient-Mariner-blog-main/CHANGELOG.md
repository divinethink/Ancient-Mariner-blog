# CHANGELOG

## Unreleased

- P0a: static পরিবেশন, `_headers`, Firestore REST-পড়া যাচাই সম্পন্ন; হ্যালো-পেজ সরানো, Firestore rule deny-all।
- P0b: Tailwind v4, ESLint 9 (architecture guardrails), Prettier, Vitest, README/CHANGELOG, CI-তে lint+test।
- P0c: data/lib/theme/i18n/error-boundary/PWA-manifest/CSP/rules-scaffold (`enums`, `datetime`, `logger`, `localStore`, `postRepo` interface, ৬ থিম token, `deploy:rules`)।
- P1a (কোড): Google Sign-In, `/login`, `POST /api/auth/session|logout`, edge `middleware.ts` (session + nonce-CSP), `AuthGate`, `lib/session.ts` (`jose`), `lib/csp.ts`, `/dashboard` স্থানধারক। Owner-যাচাই বাকি।
- P1b (কোড): Firestore rules (`posts`/`slugs`/`siteSettings` + deny-all), `posts.body` index exemption, Emulator কনফিগ (`firebase.json`), rules-test (`tests/rules`, `npm run test:rules`), CI-তে rules-test gate। Production deploy ও CI-যাচাই বাকি।
- P2a-১ (কোড): `lib/slug.ts`, `postRepo` Zod boundary (+`drafts`, patch, defensive read), `postRepo.client.ts` (পথ ক: atomic post+slug-lock, rename, drafts), `postRepo.server.ts` + `firestoreRest.ts` (পথ খ: build-সময়ের REST-পড়া), `drafts` rules, composite index (`status`+`visibility`+`publishedAt desc`), Emulator-এ repo integration test। UI নেই।
- P2a-২ক (কোড): Tiptap editor (allowlist, lazy), IndexedDB autosave (`draftStore`) ও caret/scroll পুনঃস্থাপন, লাইব্রেরি হোম, `/dashboard/posts/new|[id]/edit`, `/dashboard/menu`, dashboard nav, `postRepo.list()`, logout-এ unsynced-confirm। Firestore sync ও Publish panel P2a-২খ-তে।
- P2a-২খ (কোড): Firestore sync engine (`syncEngine`, `postSync`, `lib/syncPlan`; idle/blur/manual, conflict-সতর্কতা, race-নিরাপদ `sync:<id>` dirty-তথ্য), Publish/Metadata panel, `postRepo.update/saveEdit/applyDraft` এখন `updatedAt` ফেরত দেয়, `lib/datetime`-এ `toZonedInput/fromZonedInput`, `lib/publish`, লাইব্রেরি-খোলা ও logout-এ সব dirty ড্রাফট sync। CI ও owner-যাচাই বাকি; rebuild trigger P2a-৩-এ।

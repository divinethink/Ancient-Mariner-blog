import { createRequire } from "node:module";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { type D1Like, cleanupRateLimits, consumeLimit, readStats, recordView } from "./counterRepo";
import { statsWindow } from "@/lib/stats";
import { MAX_POSTS_PER_VISITOR_PER_DAY } from "@/lib/views";
import { readFileSync } from "node:fs";

vi.mock("@opennextjs/cloudflare", () => ({ getCloudflareContext: () => ({ env: {} }) }));

// node:sqlite (Node ≥২২.৫) — vite-এর builtin-তালিকা এড়াতে require দিয়ে
const { DatabaseSync } = createRequire(import.meta.url)("node:sqlite") as { DatabaseSync: new (p: string) => SqliteDb };
type SqliteDb = { exec(s: string): void; prepare(s: string): { run(...v: unknown[]): { changes: number | bigint }; all(...v: unknown[]): Record<string, unknown>[] } };

function fakeD1(raw: SqliteDb): D1Like {
  return {
    prepare: (sql) => ({
      bind: (...v) => ({
        run: async () => ({ meta: { changes: Number(raw.prepare(sql).run(...v).changes) } }),
        all: async () => ({ results: raw.prepare(sql).all(...v) }),
      }),
    }),
  };
}

let raw: SqliteDb;
let db: D1Like;
const all = (sql: string) => raw.prepare(sql).all();
const view = (o: Partial<Parameters<typeof recordView>[1]> = {}) =>
  recordView(db, { postId: "P1", day: "2026-10-10", country: "BD", referrer: "direct", visitorKey: "v:a", postKey: "p:P1:a", ...o });

beforeEach(() => {
  raw = new DatabaseSync(":memory:");
  raw.exec(readFileSync("migrations/d1/0001_init.sql", "utf8"));
  db = fakeD1(raw);
});

describe("recordView", () => {
  it("প্রথম ভিউ গোনা: viewCounts ও dailyVisitors", async () => {
    expect(await view()).toBe("counted");
    expect(all("SELECT postId, n FROM viewCounts")).toEqual([{ postId: "P1", n: 1 }]);
    expect(all("SELECT day, n FROM dailyVisitors")).toEqual([{ day: "2026-10-10", n: 1 }]);
  });
  it("একই ভিজিটর+পোস্ট+দিন আবার = duplicate, কিছু বাড়ে না (idempotent)", async () => {
    await view();
    expect(await view()).toBe("duplicate");
    expect(all("SELECT n FROM viewCounts")).toEqual([{ n: 1 }]);
    expect(all("SELECT n FROM dailyVisitors")).toEqual([{ n: 1 }]);
  });
  it("একই ভিজিটরের আরেক পোস্ট: ভিউ +১ কিন্তু ভিজিটর একই", async () => {
    await view();
    expect(await view({ postId: "P2", postKey: "p:P2:a" })).toBe("counted");
    expect(all("SELECT n FROM dailyVisitors")).toEqual([{ n: 1 }]);
    expect(all("SELECT COUNT(*) AS c FROM viewCounts")).toEqual([{ c: 2 }]);
  });
  it("ভিন্ন ভিজিটর: একই row-তে n=২, ভিজিটর ২", async () => {
    await view();
    await view({ visitorKey: "v:b", postKey: "p:P1:b" });
    expect(all("SELECT n FROM viewCounts")).toEqual([{ n: 2 }]);
    expect(all("SELECT n FROM dailyVisitors")).toEqual([{ n: 2 }]);
  });
  it("ভিন্ন দেশ/referrer আলাদা row", async () => {
    await view();
    await view({ visitorKey: "v:b", postKey: "p:P1:b", country: "US", referrer: "google.com" });
    expect(all("SELECT COUNT(*) AS c FROM viewCounts")).toEqual([{ c: 2 }]);
  });
  it("একজনের দিনে পোস্ট-সীমা ছাড়ালে limited", async () => {
    let last = "";
    for (let i = 0; i < MAX_POSTS_PER_VISITOR_PER_DAY + 3; i++) last = await view({ postId: `P${i}`, postKey: `p:P${i}:a` });
    expect(last).toBe("limited");
    expect(all("SELECT COUNT(*) AS c FROM viewCounts")).toEqual([{ c: MAX_POSTS_PER_VISITOR_PER_DAY }]);
  });
});

describe("cleanupRateLimits", () => {
  it("পুরনো dedupe row মোছে, viewCounts/dailyVisitors অক্ষত", async () => {
    await view({ day: "2026-10-01", visitorKey: "v:old", postKey: "p:P1:old" });
    await view({ day: "2026-10-10" });
    expect(await cleanupRateLimits(db, "2026-10-08")).toBe(2);
    expect(all("SELECT windowStart FROM rateLimits").every((r) => r.windowStart === "2026-10-10")).toBe(true);
    expect(all("SELECT COUNT(*) AS c FROM viewCounts")).toEqual([{ c: 2 }]);
    expect(all("SELECT COUNT(*) AS c FROM dailyVisitors")).toEqual([{ c: 2 }]);
  });
});

describe("readStats", () => {
  const NOW = Date.UTC(2026, 9, 10, 12, 0, 0);
  const seed = () => {
    raw.exec(`
      INSERT INTO viewCounts VALUES ('P1','2026-10-10','BD','google.com',5),('P1','2026-10-09','BD','direct',2),
        ('P2','2026-10-10','US','direct',3),('P1','2026-10-02','BD','direct',4),('P1','2026-09-01','BD','direct',9);
      INSERT INTO dailyVisitors VALUES ('2026-10-10',6),('2026-10-09',2),('2026-10-02',4),('2026-09-01',9);`);
  };
  it("৭ দিন: মোট, আগের ৭ দিন, দিনভিত্তিক সিরিজ, শীর্ষ তালিকা", async () => {
    seed();
    const s = await readStats(db, statsWindow("7d", NOW, "Asia/Dhaka")); // 04–10 অক্টো; আগের 27 সেপ্টে–03 অক্টো
    expect(s.views).toBe(10);
    expect(s.visitors).toBe(8);
    expect(s.prevViews).toBe(4);
    expect(s.prevVisitors).toBe(4);
    expect(s.series).toHaveLength(7);
    expect(s.series.reduce((t, p) => t + p.n, 0)).toBe(10);
    expect(s.posts).toEqual([{ postId: "P1", n: 7 }, { postId: "P2", n: 3 }]);
    expect(s.referrers[0]).toEqual({ k: "direct", n: 5 });
    expect(s.countries[0]).toEqual({ k: "BD", n: 7 });
  });
  it("সব সময়: তুলনা নেই, মাসভিত্তিক", async () => {
    seed();
    const s = await readStats(db, statsWindow("all", NOW, "Asia/Dhaka"));
    expect(s.views).toBe(23);
    expect(s.prevViews).toBeNull();
    expect(s.series.map((p) => p.k)).toEqual(["2026-09", "2026-10"]);
    expect(s.series.map((p) => p.n)).toEqual([9, 14]);
  });
  it("ডেটা না থাকলে সব ০/খালি (ভাঙে না)", async () => {
    const s = await readStats(db, statsWindow("30d", NOW, "Asia/Dhaka"));
    expect(s.views).toBe(0);
    expect(s.posts).toEqual([]);
    expect(s.series).toHaveLength(30);
  });
});

describe("consumeLimit (মন্তব্য limiter)", () => {
  it("max পর্যন্ত true, তারপর false; row-র n সীমা ছাড়ায় না", async () => {
    const r = [] as boolean[];
    for (let i = 0; i < 4; i++) r.push(await consumeLimit(db, "ch:a:2026-10-10T05", "2026-10-10", 3));
    expect(r).toEqual([true, true, true, false]);
    expect(all("SELECT n FROM rateLimits WHERE key = 'ch:a:2026-10-10T05'")).toEqual([{ n: 3 }]);
  });
  it("ভিন্ন key (ভিন্ন উইন্ডো/ভিজিটর) স্বাধীন", async () => {
    expect(await consumeLimit(db, "k1", "2026-10-10", 1)).toBe(true);
    expect(await consumeLimit(db, "k1", "2026-10-10", 1)).toBe(false);
    expect(await consumeLimit(db, "k2", "2026-10-10", 1)).toBe(true);
  });
  it("Cron cleanup পুরনো-দিনের limiter row মোছে", async () => {
    await consumeLimit(db, "cd:a:2026-10-01", "2026-10-01", 5);
    await consumeLimit(db, "cd:a:2026-10-10", "2026-10-10", 5);
    expect(await cleanupRateLimits(db, "2026-10-09")).toBe(1);
  });
});

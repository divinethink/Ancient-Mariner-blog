"use client";

// P13b: লেখা → Markdown/HTML (ব্রাউজারে তৈরি, শুধু read; কিছু সংরক্ষণ হয় না)। ডিফল্ট = শুধু published+public।
import { useEffect, useRef, useState } from "react";
import { getBackupSource } from "@/data/backupRepo";
import { bn } from "@/i18n/bn";
import {
  buildHtml,
  buildMarkdown,
  exportFileName,
  filterByRange,
  readAllPosts,
  selectPosts,
  type BundleMeta,
  type ExportMode,
  type ExportPost,
} from "@/lib/exportBundle";
import { dayKey } from "@/lib/datetime";
import { DOCX_MIME } from "@/lib/exportDocx"; // শুধু ধ্রুবক — `docx` প্যাকেজ বোতাম চাপলে lazy লোড হয়
import { Toggle } from "@/components/ui/Toggle";
import { useSiteTimezone } from "../SiteSettingsProvider";

type Phase = "idle" | "running" | "done" | "empty" | "error";
type DocxPhase = "idle" | "building" | "error";
type Files = { md: { url: string; name: string }; html: { url: string; name: string }; count: number };

const btn = "min-h-12 w-full rounded-full bg-btn-bg px-5 font-semibold text-btn-tx disabled:opacity-50";
const dl = "inline-flex min-h-12 items-center justify-center rounded-full bg-btn-bg px-4 font-semibold text-btn-tx";
const T = bn.backup.textExport;

export function TextExportPanel() {
  const tz = useSiteTimezone();
  const [all, setAll] = useState(false);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [rangeErr, setRangeErr] = useState(false);
  const [year] = useState(() => dayKey(Date.now(), tz).slice(0, 4));
  const [phase, setPhase] = useState<Phase>("idle");
  const [read, setRead] = useState(0);
  const [files, setFiles] = useState<Files | null>(null);
  const abort = useRef<AbortController | null>(null);
  const src = useRef<{ posts: ExportPost[]; meta: BundleMeta; now: Date } | null>(null);
  const [docx, setDocx] = useState<DocxPhase>("idle");
  const [docxFile, setDocxFile] = useState<{ url: string; name: string } | null>(null);

  useEffect(() => () => abort.current?.abort(), []);
  useEffect(
    () => () => {
      if (files) {
        URL.revokeObjectURL(files.md.url);
        URL.revokeObjectURL(files.html.url);
      }
    },
    [files],
  );

  useEffect(
    () => () => {
      if (docxFile) URL.revokeObjectURL(docxFile.url);
    },
    [docxFile],
  );

  async function makeDocx() {
    if (!src.current || docx === "building") return;
    setDocx("building");
    try {
      const { posts, meta, now } = src.current;
      const { buildDocx } = await import("@/lib/exportDocx");
      const buf = await buildDocx(posts, meta);
      const url = URL.createObjectURL(new Blob([buf], { type: DOCX_MIME }));
      setDocxFile({ url, name: exportFileName(now, "docx") });
      setDocx("idle");
    } catch {
      setDocx("error"); // Markdown/HTML অক্ষত থাকে
    }
  }

  async function run() {
    if (phase === "running") return;
    if (from && to && from > to) {
      setRangeErr(true);
      return;
    }
    setRangeErr(false);
    const ac = new AbortController();
    abort.current = ac;
    setPhase("running");
    setRead(0);
    setFiles(null);
    setDocxFile(null);
    setDocx("idle");
    src.current = null;
    try {
      const mode: ExportMode = all ? "all" : "published";
      const docs = await readAllPosts(await getBackupSource(), { signal: ac.signal, onProgress: setRead });
      const range = { from: from || undefined, to: to || undefined };
      const posts = filterByRange(selectPosts(docs, mode), range, tz);
      if (posts.length === 0) {
        setPhase("empty");
        return;
      }
      const now = new Date();
      const meta = { heading: T.heading, exportedAt: now, timeZone: tz, mode, range };
      const url = (text: string, type: string) => URL.createObjectURL(new Blob([text], { type: `${type};charset=utf-8` }));
      src.current = { posts, meta, now };
      setFiles({
        md: { url: url(buildMarkdown(posts, meta), "text/markdown"), name: exportFileName(now, "md") },
        html: { url: url(buildHtml(posts, meta), "text/html"), name: exportFileName(now, "html") },
        count: posts.length,
      });
      setPhase("done");
    } catch {
      setPhase(ac.signal.aborted ? "idle" : "error"); // আংশিক ফাইল কখনো দেওয়া হয় না
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">{T.intro}</p>
      <fieldset disabled={phase === "running"}>
        <legend className="sr-only">{T.all}</legend>
        <Toggle
          checked={all}
          onChange={setAll}
          label={T.all}
          hint={<span className={all ? "text-accent-text" : undefined}>{all ? T.allWarn : T.onlyPublished}</span>}
        />
      </fieldset>

      <fieldset className="space-y-2" disabled={phase === "running"}>
        <legend className="font-semibold">{T.rangeTitle}</legend>
        <p className="text-sm text-muted">{T.rangeHint}</p>
        <div className="grid grid-cols-2 gap-3">
          <label className="min-w-0 text-sm">
            {T.rangeFrom}
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1 block min-h-11 w-full rounded-xl border border-line bg-surface px-3" />
          </label>
          <label className="min-w-0 text-sm">
            {T.rangeTo}
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="mt-1 block min-h-11 w-full rounded-xl border border-line bg-surface px-3" />
          </label>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => {
              setFrom(`${year}-01-01`);
              setTo(`${year}-12-31`);
            }}
            className="min-h-11 rounded-full border border-line px-4 text-sm"
          >
            {T.rangeThisYear}
          </button>
          <button
            type="button"
            onClick={() => {
              setFrom("");
              setTo("");
              setRangeErr(false);
            }}
            className="min-h-11 rounded-full border border-line px-4 text-sm"
          >
            {T.rangeClear}
          </button>
        </div>
        {rangeErr && (
          <p role="alert" className="text-accent-text">
            {T.rangeInvalid}
          </p>
        )}
      </fieldset>

      {phase === "error" && (
        <p role="alert" className="text-accent-text">
          {T.failed}
        </p>
      )}
      {phase === "empty" && <p role="status">{T.empty}</p>}
      {phase === "running" ? (
        <div className="space-y-2">
          <p role="status" className="text-muted">
            {T.running(read)}
          </p>
          <button type="button" onClick={() => abort.current?.abort()} className="min-h-11 w-full rounded-full border border-line px-5">
            {T.cancel}
          </button>
        </div>
      ) : (
        <button type="button" onClick={() => void run()} className={btn}>
          {phase === "done" ? T.again : phase === "error" ? bn.backup.retry : T.startBtn}
        </button>
      )}
      {phase === "done" && files && (
        <div className="space-y-2">
          <p role="status">{T.ready(files.count)}</p>
          <div className="grid grid-cols-2 gap-3">
            <a href={files.md.url} download={files.md.name} className={dl}>
              ⬇ {T.mdLabel}
            </a>
            <a href={files.html.url} download={files.html.name} className={dl}>
              ⬇ {T.htmlLabel}
            </a>
          </div>
          {docxFile ? (
            <p>
              <a href={docxFile.url} download={docxFile.name} className={`${dl} w-full`}>
                ⬇ {T.docxLabel}
              </a>
            </p>
          ) : (
            <p>
              <button
                type="button"
                onClick={() => void makeDocx()}
                disabled={docx === "building"}
                className="min-h-12 w-full rounded-full border border-line px-5 disabled:opacity-50"
              >
                {docx === "building" ? T.docxBuilding : T.docxBtn}
              </button>
            </p>
          )}
          {docx === "error" && (
            <p role="alert" className="text-accent-text">
              {T.docxFailed}
            </p>
          )}
          {docxFile && <p className="text-sm text-muted">{T.docxHint}</p>}
          <p className="text-sm text-muted">{bn.backup.keepSafe}</p>
        </div>
      )}
    </div>
  );
}
